﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Vetta.Sistema.Domain
{
    public class Cliente : BaseDomain
    {
        public Cliente()
        {
            this.Contatos = new List<Contato>();
            this.Classificacao = new Classificacao();
        }

        public virtual int? Id { get; set; }

        [Required(ErrorMessage ="O nome do cliente é obrigatório.", AllowEmptyStrings = false)]
        [MaxLength(100, ErrorMessage = "O nome do cliente deve ter no máximo 100 caracteres.")]
        public virtual string Nome { get; set; }

        [MaxLength(100, ErrorMessage = "A razão social do cliente deve ter no máximo 100 caracteres.")]
        public virtual string RazaoSocial { get; set; }

        public virtual int TipoCliente { get; set; }

        public virtual string Cep { get; set; }

        [Required(ErrorMessage = "O email do cliente é obrigatório.", AllowEmptyStrings = false)]
        [MaxLength(100, ErrorMessage = "O email do cliente deve ter no máximo 100 caracteres.")]
        [RegularExpression(".+\\@.+\\..+", ErrorMessage = "Informe um email válido.")]
        public virtual string Email { get; set; }

        public virtual int IdClassificaco { get; set; }

        [Required(ErrorMessage = "O CPF/CNPJ do cliente é obrigatório.", AllowEmptyStrings = false)]
        public virtual string CpfCnpj { get; set; }

        public virtual Classificacao Classificacao { get; set; }

        public virtual IList<Contato> Contatos { get; set; }


    }
}
