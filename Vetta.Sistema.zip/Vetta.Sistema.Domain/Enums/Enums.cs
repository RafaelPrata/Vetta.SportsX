﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vetta.Sistema.Domain.Enums
{
    public enum TipoCliente
    {
        PessoaFisica = 1,
        PessoaJuridica = 2
    }
}
