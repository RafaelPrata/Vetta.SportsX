﻿using System;

namespace Vetta.Sistema.Domain
{
    public class Contato
    {
        public Contato()
        {

        }

        public virtual int Id { get; set; }

        public virtual int IdCliente { get; set; }

        public virtual string Telefone { get; set; }

        public virtual Cliente Cliente { get; set; }
    }
}
