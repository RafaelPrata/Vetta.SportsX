﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Vetta.Sistema.Domain
{
    public abstract class BaseDomain
    {
        private bool _valido;
        public bool Valido { get => _valido; }
        public IEnumerable<ValidationResult> Validar()
        {
            var result = new List<ValidationResult>();

            var context = new ValidationContext(this, null, null);

            Validator.TryValidateObject(this, context, result, true);

            this._valido = result.Count == 0;

            return result;
        }
    }
}
