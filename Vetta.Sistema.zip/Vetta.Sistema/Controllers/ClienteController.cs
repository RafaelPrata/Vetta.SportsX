﻿using Microsoft.Ajax.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vetta.Sistema.Domain;
using Vetta.Sistema.Presentation.Models;
using Vetta.Sistema.Repository.Contracts;
using Vetta.Sistema.Repository.Impl;
using Vetta.Sistema.Repository.Util;

namespace Vetta.Sistema.Presentation.Controllers
{
    public class ClienteController : Controller
    {
        private IClienteRepository clienteRepository;
        private IClassificacaoRepository classificacaoRepository;

        public ClienteController()
        {
            this.clienteRepository = new ClienteRepository();
            this.classificacaoRepository = new ClassificacaoRepository();
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [HttpPost]
        public ActionResult ListaCliente()
        {
            try
            {
                var tipoCliente = Convert.ToInt16(Request.Params["rbTipoCliente"].ToString());

                var lista = this.clienteRepository.GetAllByTipoCliente(tipoCliente).ToList();

                var listaClientes = lista.Select(x => new ClienteViewModel
                {
                    Cep = x.Cep,
                    CpfCnpj = x.CpfCnpj,
                    DescricaoClassificaco = x.Classificacao.Descricao,
                    Email = x.Email,
                    Id = x.Id,
                    Nome = x.Nome,
                    Contatos = x.Contatos.Select(y => y.Telefone).ToList()
                });

                return View("ListaCliente", listaClientes);

            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        public ActionResult ListaCliente(int? id)
        {
            try
            {
                if (id is null)
                {

                    var lista = this.clienteRepository.GetAll().ToList();

                    var listaClientes = lista.Select(x => new ClienteViewModel
                    {
                        Cep = x.Cep,
                        CpfCnpj = x.CpfCnpj,
                        DescricaoClassificaco = x.Classificacao.Descricao,
                        Email = x.Email,
                        Id = x.Id,
                        Nome = x.Nome,
                        Contatos = x.Contatos.Select(y => y.Telefone).ToList()
                    });

                    return View("ListaCliente", listaClientes);
                }
                else
                {
                    return RedirectToAction("CadastroCliente", new { id = (int)id });
                }
            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ActionResult DeletarCliente(int id)
        {
            try
            {
                this.clienteRepository.Delete(id);

                return RedirectToAction("ListaCliente");
            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        public ActionResult CadastroCliente(int? id)
        {
            try
            {
                ClienteViewModel clienteViewModel;
                ViewBag.Message = "Cadastro de clientes.";

                var selectListClassificacao = new SelectList(this.classificacaoRepository.GetAll(), "Id", "Descricao");

                if (id != null)
                {
                    var domainCliente = this.clienteRepository.Get((int)id);

                    clienteViewModel = new ClienteViewModel
                    {
                        Id = domainCliente.Id,
                        Cep = domainCliente.Cep,
                        CpfCnpj = domainCliente.CpfCnpj,
                        Email = domainCliente.Email,
                        IdClassificaco = domainCliente.IdClassificaco,
                        Nome = domainCliente.Nome,
                        RazaoSocial = domainCliente.RazaoSocial,
                        TipoCliente = domainCliente.TipoCliente,
                        Contatos = domainCliente.Contatos.Select(x => x.Telefone).ToList(),
                    };

                    selectListClassificacao.First(x => x.Value == clienteViewModel.IdClassificaco.ToString()).Selected = true;

                    clienteViewModel.ListaClassificacao = selectListClassificacao;
                }
                else
                {
                    clienteViewModel = new ClienteViewModel
                    {
                        Contatos = new string[] { "" },
                        ListaClassificacao = selectListClassificacao
                    };
                }

                return View("CadastroCliente", clienteViewModel);
            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        public ActionResult CadastroCliente(ClienteViewModel clienteViewModel)
        {
            try
            {
                clienteViewModel.Contatos = Request.Params.GetValues("txtContato");

                var listaContatos = clienteViewModel.Contatos
                       .Where(x => string.IsNullOrWhiteSpace(x) == false && string.IsNullOrEmpty(x) == false)
                       .Select(x => new Contato { Telefone = x.Replace("_", "").Replace(" ", "").Replace("(", "").Replace(")", "").Replace("-", "") }).ToList();

                if (ModelState.IsValid)
                {
                    var domainCliente = new Cliente
                    {
                        Id = clienteViewModel.Id,
                        Cep = clienteViewModel.Cep?.Replace("-", ""),
                        CpfCnpj = clienteViewModel.CpfCnpj.Replace(".", "").Replace("-", "").Replace("/", ""),
                        Email = clienteViewModel.Email,
                        Nome = clienteViewModel.Nome,
                        RazaoSocial = clienteViewModel?.RazaoSocial,
                        TipoCliente = clienteViewModel.TipoCliente,
                        IdClassificaco = clienteViewModel.IdClassificaco,
                        Contatos = listaContatos
                    };

                    if (clienteViewModel.Id is null)
                    {
                        this.clienteRepository.Save(domainCliente);

                        clienteViewModel = new ClienteViewModel() { Contatos = new string[] { "" } };
                    }
                    else
                    {
                        this.clienteRepository.Update(domainCliente);
                    }

                    ModelState.Clear();
                }

                clienteViewModel.ListaClassificacao = new SelectList(this.classificacaoRepository.GetAll(), "Id", "Descricao");

                return View(clienteViewModel);

            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}