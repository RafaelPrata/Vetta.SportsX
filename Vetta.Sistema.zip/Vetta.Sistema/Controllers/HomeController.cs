﻿using Microsoft.Ajax.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vetta.Sistema.Domain;
using Vetta.Sistema.Presentation.Models;
using Vetta.Sistema.Repository.Contracts;
using Vetta.Sistema.Repository.Impl;

namespace Vetta.Sistema.Presentation.Controllers
{
    public class HomeController : Controller
    {
        public HomeController()
        {
            
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Sobre()
        {
            return View();
        }

        public ActionResult Contato()
        {
            return View();
        }
    }
}