﻿using System;
using System.Collections.Generic;
using Vetta.Sistema.Domain;

namespace Vetta.Sistema.Repository.Contracts
{
    public interface IContatoRepository : IDisposable
    {
        bool Save(IList<Contato> contato);
        bool Update(Contato contato);
        bool Delete(Contato contato);
        bool DeleteContatoCliente(int idCliente);
        Contato Get(int id);
        IList<Contato> GetAll();
    }
}
