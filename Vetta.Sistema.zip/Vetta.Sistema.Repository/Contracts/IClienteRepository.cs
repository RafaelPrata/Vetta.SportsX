﻿using System;
using System.Collections.Generic;
using Vetta.Sistema.Domain;

namespace Vetta.Sistema.Repository.Contracts
{
    public interface IClienteRepository : IDisposable
    {
        bool Save(Cliente cliente);
        bool Update(Cliente cliente);
        bool Delete(int id);
        Cliente Get(int id);
        IList<Cliente> GetAllByTipoCliente(int tipoCliente);
        IList<Cliente> GetAll();
    }
}
