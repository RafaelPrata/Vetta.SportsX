﻿using System;
using System.Collections.Generic;
using Vetta.Sistema.Domain;

namespace Vetta.Sistema.Repository.Contracts
{
    public interface IClassificacaoRepository : IDisposable
    {
        Classificacao Get(int id);
        IList<Classificacao> GetAll();
    }
}
