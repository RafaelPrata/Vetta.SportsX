﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Vetta.Sistema.Domain;
using Vetta.Sistema.Repository.Contracts;
using Vetta.Sistema.Repository.Util;

namespace Vetta.Sistema.Repository.Impl
{
    public class ClassificacaoRepository : BaseRepository, IClassificacaoRepository, IDisposable
    {
        public ClassificacaoRepository() : base()
        {

        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public Classificacao Get(int id)
        {
            try
            {
                return this.context.Classificacoes.ToList().First(x => x.Id == id);
            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
        }

        public IList<Classificacao> GetAll()
        {
            try
            {
                return this.context.Classificacoes.ToList();
            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
        }

    }
}
