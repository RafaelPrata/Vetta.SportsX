﻿using System;
using System.Collections.Generic;
using System.Text;
using Vetta.Sistema.Data;

namespace Vetta.Sistema.Repository.Impl
{
    public class BaseRepository
    {
        protected CadastroContext context;

        public BaseRepository()
        {
            this.context = new CadastroContext();
        }
    }
}
