﻿using System;
using System.Collections.Generic;
using System.Text;
using Vetta.Sistema.Domain;
using Vetta.Sistema.Repository.Contracts;
using Vetta.Sistema.Repository.Util;

namespace Vetta.Sistema.Repository.Impl
{
    class ContatoRepository : BaseRepository, IContatoRepository, IDisposable
    {
        public ContatoRepository() : base()
        {

        }

        public bool Delete(Contato contato)
        {
            throw new NotImplementedException();
        }

        public bool DeleteContatoCliente(int idCliente)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public Contato Get(int id)
        {
            throw new NotImplementedException();
        }

        public IList<Contato> GetAll()
        {
            throw new NotImplementedException();
        }

        public bool Save(IList<Contato> contatos)
        {
            try
            {
                this.context.AddRange(contatos);

                var retorno = this.context.SaveChanges();

                return retorno > 0;
            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
        }

        public bool Update(Contato contato)
        {
            throw new NotImplementedException();
        }
    }
}
