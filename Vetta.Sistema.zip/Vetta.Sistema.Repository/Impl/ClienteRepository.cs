﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Vetta.Sistema.Data;
using Vetta.Sistema.Domain;
using Vetta.Sistema.Repository.Contracts;
using Vetta.Sistema.Repository.Util;

namespace Vetta.Sistema.Repository.Impl
{
    public class ClienteRepository : BaseRepository, IClienteRepository, IDisposable
    {
        public ClienteRepository() : base()
        {

        }

        public bool Delete(int idCliente)
        {
            try
            {
                var cliente = this.context.Clientes.First(x => x.Id == idCliente);

                var contatosCliente = this.context.Contatos.Where(x => x.IdCliente == idCliente);

                this.context.Contatos.RemoveRange(contatosCliente);

                this.context.Clientes.Remove(cliente);

                var retorno = this.context.SaveChanges();

                return retorno > 0;
            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public Domain.Cliente Get(int id)
        {
            try
            {
                var cliente = this.context.Clientes.Single(x => x.Id == id);

                cliente.Contatos = this.context.Contatos.Where(x => x.IdCliente == cliente.Id).ToList();

                return cliente;
            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
        }

        public IList<Domain.Cliente> GetAllByTipoCliente(int tipoCliente)
        {
            try
            {
                var listaClientes = this.context.Clientes.Where(x => x.TipoCliente == tipoCliente).ToList();
                var listaClassificacao = context.Classificacoes.ToList();

                listaClientes.ForEach(cliente =>
                {
                    cliente.Classificacao = listaClassificacao.First(y => y.Id == cliente.IdClassificaco);
                    cliente.Contatos = context.Contatos.Where(x => x.IdCliente == cliente.Id).ToList();
                });

                return listaClientes;
            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
        }

        public IList<Domain.Cliente> GetAll()
        {
            try
            {
                var listaClientes = context.Clientes.ToList();
                var listaClassificacao = context.Classificacoes.ToList();

                listaClientes.ForEach(cliente =>
                {
                    cliente.Classificacao = listaClassificacao.First(y => y.Id == cliente.IdClassificaco);
                    cliente.Contatos = context.Contatos.Where(x => x.IdCliente == cliente.Id).ToList();
                });

                return listaClientes;
            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
        }

        public bool Save(Domain.Cliente cliente)
        {
            try
            {
                var listaContatos = cliente.Contatos;

                cliente.Contatos = null;
                cliente.Classificacao = null;

                this.context.Add(cliente);

                var idCliente = this.context.SaveChanges();

                foreach (var item in listaContatos)
                {
                    item.IdCliente = (int)cliente.Id;
                }

                var contatoSave = new ContatoRepository().Save(listaContatos);

                return idCliente > 0;
            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
        }

        public bool Update(Domain.Cliente cliente)
        {
            try
            {
                cliente.Classificacao = null;

                var listaContatosCliente = this.context.Contatos.Where(x => x.IdCliente == cliente.Id).ToList();

                this.context.Contatos.RemoveRange(listaContatosCliente);

                this.context.Update(cliente);

                var statusChange = this.context.SaveChanges();

                return statusChange > 0;

            }
            catch (RepositoryException ex)
            {
                throw ex;
            }
        }
    }
}
