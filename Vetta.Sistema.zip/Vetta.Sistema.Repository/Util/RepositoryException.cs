﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vetta.Sistema.Repository.Util
{
    public class RepositoryException : Exception
    {
        public RepositoryException(string errorMessage) : base(errorMessage)
        {

        }
    }
}
