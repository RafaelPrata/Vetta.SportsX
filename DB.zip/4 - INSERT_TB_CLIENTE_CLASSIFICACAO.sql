INSERT INTO [dbo].[TB_CLIENTE_CLASSIFICACAO]([Descricao])  VALUES ('Ativo')
INSERT INTO [dbo].[TB_CLIENTE_CLASSIFICACAO]([Descricao])  VALUES ('Inativo')
INSERT INTO [dbo].[TB_CLIENTE_CLASSIFICACAO]([Descricao])  VALUES ('Preferencial')



